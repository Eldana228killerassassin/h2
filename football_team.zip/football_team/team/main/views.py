from django.shortcuts import render
from django.http import HttpResponse
from .models import player
from django.template import loader
from django.shortcuts import get_object_or_404

def index(request):
    return render(request, 'main/index.html')


def team(request):
    data = player.objects.all()
    context = {
        "players": data
    }
    return render(request, 'main/team.html', context=context)


def instagram(request):
    return render(request, 'main/instagram.html')


def details(request, player_id):
    player_instance = get_object_or_404(player, pk=player_id)
    return render(request, 'main/details.html', {'player': player_instance})


