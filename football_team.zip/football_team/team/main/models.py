from django.db import models

class player(models.Model):
    name = models.CharField(max_length=255)
    surname = models.CharField(max_length=255)
    age = models.IntegerField()
    country = models.CharField(max_length=255)
    birthdate = models.DateField()
    position = models.CharField(max_length=255, default='Forward')
    def _str_(self):
        return f"Игрок {self.name} {self.surname}"